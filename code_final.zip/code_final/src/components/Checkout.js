import React, {Component} from "react"

export default class Checkout extends Component{
    render(){
        return(
            <div>Hello</div>
        )
    }
}