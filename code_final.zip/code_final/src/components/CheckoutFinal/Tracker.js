import React, {Component} from 'react'
import {Circle} from 'rc-progress'
const queryString = require('query-string');
export default class extends Component {
    constructor(props){
        super(props);
        this.state = {
            percent:5,
            date:new Date((new Date()).getTime() + 30*60000),
            orderID:0
        }
    }
    
    componentDidMount(){
        setInterval(()=> {
            this.setState({percent:this.state.percent+0.5})
        }, 1000)
        const parsed = queryString.parse(window.location.search);
        this.setState({orderID:parsed.id})
    }
    render(){
        return(
            <div style={{textAlign:"center",}}>
            <div style={{
                WebkitBoxShadow: '-2px 0px 18px 7px rgba(24,24,24,0.21)',
                MozBoxShadow: '-2px 0px 18px 7px rgba(24,24,24,0.21)',
                boxShadow: '-2px 0px 18px 7px rgba(24,24,24,0.21)',
                margin: 'auto', marginTop: '60px', borderRadius: '8px', width: '500px', height: '600px'}}>
                <h1 style={{paddingTop: '10px'}}>Track order #{this.state.orderID}</h1>
                <Circle percent={this.state.percent} strokeWidth="5" strokeColor="green" style={{width:"30%"}}  />
                <h2>Status: Your order is being picked up</h2>
                <h2>Estimated Time of Arrival: {this.state.date.toLocaleTimeString(navigator.language, {hour: '2-digit', minute:'2-digit'})
           .replace(/(:\d{2}| [AP]M)$/, "")} PM</h2>
                <h3 style={{textAlign:"center"}}>{this.state.date.toDateString()}</h3>
                <h3>Driver: John Appleseed</h3>
                <h3>Phone #: 408-123-4567</h3>
                <h4>Click <a href="/support">here</a> to contact support</h4>
             </div>
            </div>
        )
    }
}