import React, {Component} from 'react'
import axios from 'axios'
export default class NewUser extends Component{
    constructor(props){
        super(props);
        this.state = {
            name:null,
            address:null
        }
    }
    handleNChange = (event)=>{
        this.setState({name: event.target.value});
    }
    handleAChange= (event)=> {
        this.setState({address: event.target.value});
    }
    createUser = ()=> {
        axios({method:'get', url:`http://localhost:40/api/createUser/${this.state.name}`})
        window.location.href = `/track/?id=${(this.props.order.id)}`
    }

    render(){
        return (
          <div style={{ width: '40%', }}>
            <div
              style={{
                fontSize: '16px',
                display: 'flex',
                flexDirection: 'column',
              }}
            >
              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <div>Email:</div>
                <div>
                  <input type="text" value={this.props.email} disabled />
                </div>
              </div>

              <div
                style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}
              >
                <div>Name:</div>
                <div>
                  <input type="text" value={this.props.name} disabled />
                </div>
              </div>
              <div style={{
                    display: 'flex',
                    flexDirection: 'row',
                    justifyContent: 'space-between',
                  }}>
                <div>
                  Address:
                </div>
                <div>
                  <input
                    type="text"
                    value={this.state.address}
                    onChange={this.handleAChange}
                  />
                </div>
              </div>
              <div 
              style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <div>Phone #:</div>{' '}
                <div>
                  <input type="text" />
                </div>
              </div>
              <div style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <div>Instructions:</div>{' '}
                <div>
                  {' '}
                  <input type="text" />
                </div>
              </div>
              <div style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <div>Card:</div>{' '}
                <div>
                  <input type="text" />
                </div>
              </div>
              <div style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <div>CVC:</div>
                <div>
                  <input type="text" />
                </div>
              </div>
              <div style={{
                  display: 'flex',
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                }}>
                <div> Expiry:</div>
                <div>
                  {' '}
                  <input type="text" />
                </div>
              </div>
            </div>
            <button onClick={this.createUser}>Submit</button>
          </div>
        );
    }
}