import React, {Component} from 'react'

export default class Item extends Component{
    render(){
        return(
            <div style={{'display': 'flex', flexDirection: 'row', justifyContent : 'space-between'
        }}>
                <div style={{'width': '50%'}}>
                <h4>{this.props.name} x {this.props.quantity}</h4>
                </div>
                <div style={{paddingLeft:"8%", marginTop: '22px', width: '50%'}}>
                    {this.props.price.toFixed(2)}$
                    </div>
            </div>
        )
    }
}