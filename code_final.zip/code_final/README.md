## Spartan Online Delivery  


#### Requirements

- Node v12.16.3
- yarn

#### Install
`yarn install`
#### Run
`sudo yarn start`

